These C files were written by Yossi Rubner.
Check out his webpage:
http://vision.stanford.edu/~rubner/

The paper to reference is:
Y. Rubner, C. Tomasi, and L. J. Guibas. The earth mover's distance as a metric for image retrieval. International Journal of Computer Vision, 40(2):99-121, November 2000.

The Matlab wrapper was written by Simon Dixon.


Usage:
run "emd_test" to compile the mex files. 
